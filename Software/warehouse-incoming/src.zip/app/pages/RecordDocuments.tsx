import { useState, useEffect, useMemo } from 'react';
import { useI18n } from '../contexts/I18nContext';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Input } from '../components/ui/input';
import { Button } from '../components/ui/button';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '../components/ui/table';
import { WeighingRecord } from '../types';
import { toast } from 'sonner';
import { Search, Printer, Trash2, FileText } from 'lucide-react';

export default function RecordDocuments() {
  const { t } = useI18n();
  const [records, setRecords] = useState<WeighingRecord[]>([]);
  const [searchDate, setSearchDate] = useState('');
  const [searchMaterial, setSearchMaterial] = useState('');
  const [searchVendor, setSearchVendor] = useState('');

  useEffect(() => {
    loadRecords();
  }, []);

  const loadRecords = () => {
    const savedRecords = localStorage.getItem('weighingRecords');
    if (savedRecords) {
      setRecords(JSON.parse(savedRecords));
    }
  };

  const filteredRecords = useMemo(() => {
    return records.filter(record => {
      const matchDate = !searchDate || record.date.includes(searchDate);
      const matchMaterial = !searchMaterial || 
        record.labelProductNumber.toLowerCase().includes(searchMaterial.toLowerCase()) ||
        record.batch.toLowerCase().includes(searchMaterial.toLowerCase());
      const matchVendor = !searchVendor || 
        record.vendorName.toLowerCase().includes(searchVendor.toLowerCase());
      
      return matchDate && matchMaterial && matchVendor;
    });
  }, [records, searchDate, searchMaterial, searchVendor]);

  const handleDelete = (id: string) => {
    if (confirm('Apakah Anda yakin ingin menghapus rekaman ini?')) {
      const updatedRecords = records.filter(r => r.id !== id);
      setRecords(updatedRecords);
      localStorage.setItem('weighingRecords', JSON.stringify(updatedRecords));
      toast.success(t('recordDeleted'));
    }
  };

  const handlePrint = (record: WeighingRecord) => {
    // Create a print-friendly view
    const printWindow = window.open('', '', 'width=800,height=600');
    if (printWindow) {
      printWindow.document.write(`
        <html>
          <head>
            <title>Weighing Record - ${record.id}</title>
            <style>
              body { font-family: Arial, sans-serif; padding: 20px; }
              .header { text-align: center; margin-bottom: 30px; }
              .info { margin-bottom: 20px; }
              .info-row { display: flex; margin-bottom: 10px; }
              .info-label { width: 200px; font-weight: bold; }
              .weights { margin-top: 30px; border: 2px solid #000; padding: 20px; }
              .weight-item { font-size: 20px; margin: 10px 0; }
            </style>
          </head>
          <body>
            <div class="header">
              <h1>WAREHOUSE WEIGHING RECORD</h1>
              <p>Date: ${record.date} | Time: ${record.time}</p>
            </div>
            <div class="info">
              <div class="info-row">
                <div class="info-label">Vendor:</div>
                <div>${record.vendorName}</div>
              </div>
              <div class="info-row">
                <div class="info-label">Packaging Type:</div>
                <div>${record.packagingType}</div>
              </div>
              <div class="info-row">
                <div class="info-label">Reference Odoo:</div>
                <div>${record.referenceOdoo}</div>
              </div>
              <div class="info-row">
                <div class="info-label">Batch:</div>
                <div>${record.batch}</div>
              </div>
              <div class="info-row">
                <div class="info-label">Product Number:</div>
                <div>${record.labelProductNumber}</div>
              </div>
            </div>
            <div class="weights">
              <div class="weight-item">Gross Weight: ${record.gross} kg</div>
              <div class="weight-item">Tare Weight: ${record.tare} kg</div>
              <div class="weight-item" style="font-size: 24px; font-weight: bold; margin-top: 20px;">
                Net Weight: ${record.net} kg
              </div>
            </div>
          </body>
        </html>
      `);
      printWindow.document.close();
      printWindow.print();
    }
  };

  return (
    <div className="p-8">
      <div className="mb-6">
        <h1 className="text-3xl mb-2">{t('recordDocuments')}</h1>
        <p className="text-gray-600">Riwayat penimbangan barang incoming</p>
      </div>

      {/* Search Filters */}
      <Card className="mb-6">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Search className="w-5 h-5" />
            {t('search')}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <label className="text-sm text-gray-600">{t('searchByDate')}</label>
              <Input
                type="date"
                value={searchDate}
                onChange={(e) => setSearchDate(e.target.value)}
                placeholder={t('date')}
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm text-gray-600">{t('searchByMaterial')}</label>
              <Input
                value={searchMaterial}
                onChange={(e) => setSearchMaterial(e.target.value)}
                placeholder={t('material')}
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm text-gray-600">{t('searchByVendor')}</label>
              <Input
                value={searchVendor}
                onChange={(e) => setSearchVendor(e.target.value)}
                placeholder={t('vendor')}
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Records Table */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <span className="flex items-center gap-2">
              <FileText className="w-5 h-5" />
              Daftar Rekaman ({filteredRecords.length})
            </span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          {filteredRecords.length > 0 ? (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>{t('date')}</TableHead>
                    <TableHead>{t('time')}</TableHead>
                    <TableHead>{t('vendor')}</TableHead>
                    <TableHead>{t('packaging')}</TableHead>
                    <TableHead>{t('batch')}</TableHead>
                    <TableHead>{t('labelProductNumber')}</TableHead>
                    <TableHead className="text-right">{t('gross')} (kg)</TableHead>
                    <TableHead className="text-right">{t('tare')} (kg)</TableHead>
                    <TableHead className="text-right">{t('net')} (kg)</TableHead>
                    <TableHead className="text-center">{t('actions')}</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredRecords.map((record) => (
                    <TableRow key={record.id}>
                      <TableCell>{record.date}</TableCell>
                      <TableCell>{record.time}</TableCell>
                      <TableCell>{record.vendorName}</TableCell>
                      <TableCell>{record.packagingType}</TableCell>
                      <TableCell>{record.batch}</TableCell>
                      <TableCell>{record.labelProductNumber}</TableCell>
                      <TableCell className="text-right">{record.gross.toFixed(2)}</TableCell>
                      <TableCell className="text-right">{record.tare.toFixed(2)}</TableCell>
                      <TableCell className="text-right font-medium">{record.net.toFixed(2)}</TableCell>
                      <TableCell>
                        <div className="flex gap-2 justify-center">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handlePrint(record)}
                          >
                            <Printer className="w-4 h-4" />
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleDelete(record.id)}
                          >
                            <Trash2 className="w-4 h-4 text-red-500" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          ) : (
            <div className="text-center py-12 text-gray-400">
              <FileText className="w-16 h-16 mx-auto mb-4 opacity-50" />
              <p className="text-lg">{t('noRecords')}</p>
              <p className="text-sm mt-2">Belum ada data penimbangan yang tersimpan</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
